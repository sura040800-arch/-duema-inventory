#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
デュエル・マスターズ公式カード検索からカードDBを作る個人用インポーター。
実行:
  pip install -r requirements.txt
  python scrape_official.py

結果:
  cards.json

注意:
- 公式サイトへの大量アクセスになるため、間隔を空けて取得します。
- 個人利用を想定しています。サイトの利用条件・robots.txt等を確認してください。
- 取得件数は実行時点の公式検索結果に依存します。
"""
import json, re, time, sys
from urllib.parse import urljoin, urlparse, parse_qs, urlencode, quote
import requests
from bs4 import BeautifulSoup

BASE="https://dm.takaratomy.co.jp"
SEARCH=BASE+"/card/"
OUT="cards.json"
PER_PAGE_GUESS=40
DELAY=0.7
HEADERS={"User-Agent":"Mozilla/5.0 (compatible; DuemaInventoryPersonal/1.0)"}

def get(url):
    r=requests.get(url,headers=HEADERS,timeout=30)
    r.raise_for_status()
    r.encoding=r.apparent_encoding or "utf-8"
    return r.text

def search_url(page):
    # Official search uses a JSON object in the v query parameter.
    v={"suggest":"on","keyword":"","keyword_type":[],"culture_cond":["単色","多色"],
       "pagenum":str(page),"sort":"release_new"}
    return SEARCH+"?"+urlencode({"v":json.dumps(v,ensure_ascii=False,separators=(",",":"))})

def text(el):
    return re.sub(r"\s+"," ",el.get_text(" ",strip=True)) if el else ""

def first_image(soup, card_url):
    # Prefer the card image near the detail content.
    for img in soup.find_all("img"):
        src=img.get("src") or img.get("data-src") or ""
        alt=img.get("alt","")
        if src and ("card" in src.lower() or alt):
            return urljoin(card_url,src)
    return ""

def parse_detail(url):
    soup=BeautifulSoup(get(url),"html.parser")
    title=text(soup.find("h1")) or text(soup.title)
    data={"id":parse_qs(urlparse(url).query).get("id",[""])[0],
          "url":url,"name":title,"number":"","type":"","civilization":"",
          "rarity":"","power":"","cost":"","mana":"","race":"",
          "ability":"","flavor":"","illustrator":"","image":""}
    # The official detail pages expose labeled fields as text. Use the visible labels.
    body=soup.get_text("\n",strip=True)
    m=re.search(r"^(.+?)\(([^()]+)\)\s*$",title)
    if m:
        data["name"]=m.group(1).strip()
        data["number"]=m.group(2).strip()
    labels={
      "カードの種類":"type","文明":"civilization","レアリティ":"rarity",
      "パワー":"power","コスト":"cost","マナ":"mana","種族":"race",
      "イラストレーター":"illustrator","特殊能力":"ability","フレーバー":"flavor"
    }
    # Parse definition-list/table-like structures first.
    for lab,key in labels.items():
        node=soup.find(string=lambda s: isinstance(s,str) and s.strip()==lab)
        if node:
            parent=node.parent
            # Value is often a sibling/next cell.
            cand=[]
            for x in list(parent.next_siblings)[:4]:
                if getattr(x,"get_text",None):
                    cand.append(text(x))
            if cand and cand[0]:
                data[key]=cand[0]
            elif parent.parent:
                txt=text(parent.parent)
                txt=txt.replace(lab,"",1).strip()
                if txt: data[key]=txt[:1000]
    data["image"]=first_image(soup,url)
    # Fallback regexes from rendered text
    for lab,key in [("カードの種類","type"),("文明","civilization"),("レアリティ","rarity"),
                    ("パワー","power"),("コスト","cost"),("マナ","mana"),("種族","race")]:
        if not data[key]:
            mm=re.search(re.escape(lab)+r"\s*[|：:]\s*([^\n|]+)",body)
            if mm:data[key]=mm.group(1).strip()
    return data

def list_detail_urls(page_html):
    soup=BeautifulSoup(page_html,"html.parser")
    out=[]
    for a in soup.find_all("a",href=True):
        href=a["href"]
        if "/card/detail/" in href and "id=" in href:
            u=urljoin(BASE,href)
            if u not in out: out.append(u)
    return out

def main():
    print("公式カードDBの取得を開始します。")
    first=get(search_url(1))
    m=re.search(r"(\d[\d,]*)枚",BeautifulSoup(first,"html.parser").get_text(" ",strip=True))
    total=int(m.group(1).replace(",","")) if m else 0
    print("公式検索結果:",total,"枚")
    all_urls=[]
    seen=set()
    # Continue until a page yields no new detail links. This avoids relying on a hard-coded page count.
    page=1
    while True:
        print(f"一覧 {page}ページ目...")
        html=get(search_url(page))
        urls=list_detail_urls(html)
        new=[u for u in urls if u not in seen]
        if not new:
            break
        for u in new: seen.add(u)
        all_urls.extend(new)
        page+=1
        time.sleep(DELAY)
        if page>2000: break
    print("詳細ページ候補:",len(all_urls))
    cards=[]
    for i,u in enumerate(all_urls,1):
        try:
            cards.append(parse_detail(u))
            if i%20==0: print(f"詳細 {i}/{len(all_urls)}")
        except Exception as e:
            print("SKIP",u,e,file=sys.stderr)
        time.sleep(DELAY)
    # Stable unique by official detail id; keep separate printings.
    uniq={}
    for c in cards:
        key=c["id"] or c["url"] or (c["name"]+"|"+c["number"])
        uniq[key]=c
    cards=list(uniq.values())
    with open(OUT,"w",encoding="utf-8") as f:
        json.dump(cards,f,ensure_ascii=False,indent=2)
    print("完了:",len(cards),"枚 ->",OUT)
    if total and abs(len(cards)-total)>50:
        print("警告: 公式表示件数との差が大きいです。サイト構造変更の可能性があります。")

if __name__=="__main__":
    main()
