# デュエマ在庫管理（スマホ用）

スマホだけで使うことを想定した、GitHub Pages版です。

## あなたがやること

1. GitHubアカウントを作る/ログインする
2. 新しいRepository（リポジトリ）を1個作る
3. このフォルダの中身を全部アップロードする
4. Settings → Pages → GitHub Actions を公開元にする
5. Actions → Update official Duel Masters cards → Run workflow を1回押す
6. 数分〜しばらく待つ
7. Pagesに表示されたURLをiPhoneのSafariで開く

以後、カードDBは毎週自動更新されます。
またActionsから手動更新もできます。

## 注意
- 公式サイトの公開ページを読み取ってカードDBを作ります。
- 取得時間はカード数や公式サイトの応答によって変わります。
- 公式サイトの利用条件・robots.txt等を確認し、過度なアクセスを避けてください。
